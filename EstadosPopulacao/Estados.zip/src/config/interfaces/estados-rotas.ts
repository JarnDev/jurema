export default interface EstadosRotas {
  home: string;
}
